<?php
try{
class Autoloader {
    static public function loader($className) {
        $filename = str_replace('\\', '/', $className) . ".php";
        if (file_exists($filename)) {
            require_once($filename);
            if (class_exists($className)) {
                return TRUE;
            }
        }
        return FALSE;
    }
}
spl_autoload_register('Autoloader::loader');

require_once($_SERVER["DOCUMENT_ROOT"]."/tcpdf_tester/tcpdf/common/tcpdf_autoconfig.php");
include_once($_SERVER["DOCUMENT_ROOT"]."/tcpdf_tester/tcpdf/common/tcpdf_config.php");

//manipulateMetadata
///*
$path="start01.3.pdf";
$r=fopen($path,"r");
$bin=fread($r, filesize($path));
$xmp=new \tcpdf\metadata\XMP(new \tcpdf\parser\Parser($bin));
$dat=$xmp->manipulateMetadata(array(array("email"=>"erdo.t@gmail.com", "level"=>"1"), array("email"=>"erdo.ts@freemail.hu", "level"=>"2")));
fclose($r);

$r2=fopen("cel01.pdf", "wb");
fwrite($r2, $bin.$dat);
fclose($r2);
//*/
/*---*/

//readMetadataSignature
/*
$r=fopen("start02.pdf","r");
$bin=fread($r, filesize('start02.pdf'));
$xmp=new \tcpdf\metadata\XMP(new \tcpdf\parser\Parser($bin));
var_dump($xmp->readMetadataSignature());
fclose($r);
*/
}catch(Exception $e){echo $e->getMessage().$e->getLine().$e->getFile();}